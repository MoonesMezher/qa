const express = require('express');
const router = express.Router();

// methods
const { addNewCard, createPaymentIntent } = require('../controllers/paymentController');

// middlewares
const requireAuth = require('../middlewares/requireAuth')
const authorize = require('../middlewares/roleMiddleware')

// Route to add a new card
router.post('/add-new-card', [requireAuth, authorize(["user"])], addNewCard);

router.post('/create-payment-intent', [requireAuth, authorize(["user"])], createPaymentIntent);

module.exports = router;