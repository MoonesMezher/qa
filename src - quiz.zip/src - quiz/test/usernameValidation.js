const validateUsername = require("../helpers/usenameValidation");

console.log(validateUsername('moones.mezher'));