const { onlineGameBot, generateRandomBot } = require("../bot/onllineGameBot");

// console.log(onlineGameBot(questions, 0.6));
const x = generateRandomBot([]);

console.log(x.id)