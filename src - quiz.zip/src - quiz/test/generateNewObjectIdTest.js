const { default: mongoose } = require("mongoose");

console.log(new mongoose.Types.ObjectId());